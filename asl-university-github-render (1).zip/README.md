# ASL University — GitHub Pages + Render Multi-User

This package is prepared as a small monorepo for your existing GitHub Pages site.

## Structure

```text
ASLuniversity/
├── index.html                 # patched public ASL University homepage
├── api-config.js              # Render backend URL goes here after deployment
├── render.yaml                # Render Blueprint
└── backend/
    ├── server.js              # Express API + sessions + protected pages
    ├── member.html            # private member dashboard
    ├── package.json
    ├── .env.example
    └── health-check.html
```

Keep the rest of your existing GitHub Pages assets/files in the repository. Replace the existing `index.html` with the one in this package, and add `api-config.js`, `render.yaml`, and the `backend/` folder.

## What runs where

- GitHub Pages: public website and public assets.
- Render: Node/Express authentication API, sessions, database connection, and private member pages.
- PostgreSQL: user records and sessions.

GitHub Pages is for static site content; it does not execute Node/Express server code. Render Web Services are designed for Express apps. citeturn0search2turn2search1

## 1) Put the files in your existing GitHub repo

Repository:

`https://github.com/asluniversity/ASLuniversity`

Do not delete the existing images or other site pages. Add/replace only the files described above.

## 2) Create the Render service

The included `render.yaml` is a Render Blueprint. It uses `rootDir: backend`, so Render ignores the public GitHub Pages files when building the backend. Render supports this monorepo pattern. citeturn3search0turn3search1

The Blueprint creates a free Node Web Service and a free Render Postgres database and wires `DATABASE_URL` automatically. Render supports these resources on its free tier. citeturn2search0

### Free-tier warning

Render's free web service can sleep after 15 minutes without inbound traffic, so the first request after sleeping may take about a minute. Free Render Postgres currently expires after 30 days and is intended for testing/hobby use rather than permanent production storage. citeturn2search0

## 3) After Render deploys

Render will give you a URL similar to:

`https://asl-university-backend.onrender.com`

Open `api-config.js` and replace:

```js
window.ASL_API_BASE = 'https://REPLACE-WITH-YOUR-RENDER-SERVICE.onrender.com';
```

with your real Render URL.

Then push the change to GitHub. Render can automatically redeploy from the linked branch, while GitHub Pages can publish changes to the site. citeturn0search0turn0search3

## 4) Authentication flow

The homepage now calls the Render API for:

- `GET /api/me`
- `POST /api/login`
- `POST /api/register`
- `POST /api/logout`

Passwords are hashed with bcrypt. Sessions are stored in PostgreSQL rather than the web service's local filesystem.

The backend uses `FRONTEND_ORIGIN=https://asluniversity.github.io` and credentialed CORS so the GitHub Pages frontend can call the API. Render recommends environment variables for secrets; do not commit `.env` or credentials. citeturn3search6

## 5) Private pages

Pages that contain private member information should live inside `backend/`, not in the public GitHub Pages root.

The backend already protects:

- `/member.html`
- `/asl-account-journal*.html`
- `/asl-xauusd-analysis.html`

Copy your real private account/journal/analysis HTML files into `backend/` before deploying those pages.

Do not put private account balances, member records, or other sensitive information in the public GitHub Pages source.

## Local backend test

From `backend/`:

```bash
npm install
npm start
```

A local PostgreSQL database is required because this production version no longer uses SQLite.

## Future PWA

Once the online login flow is stable, the public frontend can be made installable as a PWA by adding a manifest, service worker, icons, and HTTPS metadata. GitHub Pages provides HTTPS for Pages sites. citeturn0search4
