// Set this to your Render backend URL after deployment.
// Example: https://asl-university-backend.onrender.com
window.ASL_API_BASE = 'https://REPLACE-WITH-YOUR-RENDER-SERVICE.onrender.com';
